# fall-detection
Code for Duke University EGR 101 section2 fall assessment group 1.
